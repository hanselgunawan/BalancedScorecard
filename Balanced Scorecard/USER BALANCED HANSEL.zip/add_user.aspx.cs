﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Security.Cryptography;

namespace Balanced_Scorecard
{
    public partial class add_user : System.Web.UI.Page
    {
        string str_connect = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        string str_connect2 = ConfigurationManager.ConnectionStrings["HumanCapitalConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var page = Request.QueryString["page"];
                DropDownListStatus.Items.Add("Yes");
                DropDownListStatus.Items.Add("No");

                //disable Name, Organization, Job Title, Additional Group, Scorecard Group
                TextBoxName.Attributes.Add("disabled", "true");
                TextBoxOrganization.Attributes.Add("disabled", "true");
                TextBoxJobTitle.Attributes.Add("disabled", "true");
                TextBoxAdditional.Attributes.Add("disabled", "true");
                TextBoxGroup.Attributes.Add("disabled", "true");

                check_NIK.Attributes.Add("style", "visibility:hidden; margin-bottom:-20px !important; margin-top:0px !important");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-40px !important; margin-top:5px !important");

                cancel_add.Attributes.Add("href", "scorecard_user.aspx?page="+page+"");//kirim balik page nya!
                scorecard_user_breadcrumb.Attributes.Add("href", "scorecard_user.aspx?page=" + page + "");//kirim balik page nya!

                TextBoxColor.Attributes.Add("class", "form-group");
                TextBoxColorConfirmation.Attributes.Add("class", "form-group");
            }
        }

        protected void TextBoxConfirmation_TextChanged(object sender, EventArgs e)
        {
            if (TextBoxConfirmation.Text != TextBoxPassword.Text)//jika Confirmation Password BUKAN SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Add("disabled", "true");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:visible; color:red; font-weight:bold; margin-bottom:-25px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-error");
            }
            else//jika Confirmation Password SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Remove("disabled");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-40px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-success");
            }
        }

        protected void TextBoxNIK_TextChanged(object sender, EventArgs e)
        {
            check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-40px !important; margin-top:5px !important");

            TextBoxColorConfirmation.Attributes.Add("class", "form-group");

            using (SqlConnection conn = new SqlConnection(str_connect))
            {
                conn.Open();
                string string_select_scorecard_user = "SELECT * FROM ScorecardUser WHERE empNIK="+TextBoxNIK.Text+"";
                SqlCommand sql_select_scorecard_user = new SqlCommand(string_select_scorecard_user, conn);
                using (SqlDataReader ScorecardUserReader = sql_select_scorecard_user.ExecuteReader())
                {
                    if (ScorecardUserReader.HasRows)//jika NIK sudah ada di Database Scorecard, tidak bisa Add User lagi
                    {
                        while (ScorecardUserReader.Read())
                        {
                            SpanAddUser.Attributes.Add("disabled", "true");
                            TextBoxPassword.Attributes.Add("disabled", "true");
                            TextBoxConfirmation.Enabled = false;
                            TextBoxColor.Attributes.Add("class", "form-group has-error");
                            check_NIK.Attributes.Add("style", "visibility:visible; margin-bottom:0px !important; margin-top:5px !important; color:red; font-weight:bold");
                            check_NIK.InnerText = "Your NIK already registered";
                            TextBoxName.Value = ScorecardUserReader["empName"].ToString();
                            TextBoxOrganization.Value = ScorecardUserReader["empOrg"].ToString();
                            TextBoxJobTitle.Value = ScorecardUserReader["empJobTitle"].ToString();
                            TextBoxAdditional.Value = ScorecardUserReader["empOrgAdtGroup"].ToString();
                            TextBoxGroup.Value = ScorecardUserReader["empScorecardGroup"].ToString();
                            DropDownListStatus.SelectedValue = ScorecardUserReader["empStatus"].ToString();
                        }
                    }
                    else//jika NIK tidak ada di Database Scorecard, cek di database HRIS. Jika ditemukkan, bisa Add. Jika tidak, Add di disabled
                    {
                        using (SqlConnection conn2 = new SqlConnection(str_connect2))
                        {
                            conn2.Open();
                            string string_select_from_HRIS = "SELECT * FROM HRIS_DB WHERE empNIK=" + TextBoxNIK.Text + "";//harusnya pake query JOIN Pak Matius
                            SqlCommand sql_select_from_HRIS = new SqlCommand(string_select_from_HRIS, conn2);
                            using (SqlDataReader HRISReader = sql_select_from_HRIS.ExecuteReader())
                            {
                                if (HRISReader.HasRows)
                                {
                                    while (HRISReader.Read())
                                    {
                                        SpanAddUser.Attributes.Remove("disabled");
                                        TextBoxPassword.Attributes.Remove("disabled");
                                        TextBoxConfirmation.Enabled = true;
                                        TextBoxColor.Attributes.Add("class", "form-group has-success");
                                        check_NIK.Attributes.Add("style", "visibility:hidden; margin-bottom:-20px !important; margin-top:0px !important");
                                        TextBoxName.Value = HRISReader["empName"].ToString();
                                        TextBoxOrganization.Value = HRISReader["empOrgName"].ToString();
                                        TextBoxJobTitle.Value = HRISReader["empJobTitleName"].ToString();
                                        TextBoxAdditional.Value = HRISReader["empOrgAdtGroup"].ToString();
                                        TextBoxGroup.Value = HRISReader["empGroupName"].ToString();
                                    }
                                }
                                else
                                {
                                    SpanAddUser.Attributes.Add("disabled", "true");
                                    TextBoxPassword.Attributes.Add("disabled", "true");
                                    TextBoxConfirmation.Enabled = false;
                                    TextBoxColor.Attributes.Add("class", "form-group has-error");
                                    check_NIK.Attributes.Add("style", "visibility:visible; margin-bottom:0px !important; margin-top:5px !important; color:red; font-weight:bold");
                                    check_NIK.InnerText = "Your NIK Not Found";
                                    TextBoxName.Value = "Name Not Found";
                                    TextBoxOrganization.Value = "Organization Not Found";
                                    TextBoxJobTitle.Value = "Job Title Not Found";
                                    TextBoxAdditional.Value = "Additional Group Not Found";
                                    TextBoxGroup.Value = "Scorecard Group Not Found";
                                }
                            }
                            conn2.Close();
                        }//end of Human Capital Connection
                    }
                }
                conn.Close();
            }//end of Balanced Scorecard Connection
        }

        protected void OnClickAddUser(object sender, EventArgs e)
        {
            var page = Request.QueryString["page"];
            string user_create, user_update, date_create, date_update;
            using (SqlConnection conn = new SqlConnection(str_connect))
            {
                conn.Open();
                string MD5_Password;
                string user_password = TextBoxPassword.Text;
                string string_insert_user = "INSERT INTO ScorecardUser VALUES(@empNIK, @empName, @empOrg, @empJobTitle, @empScorecardGroup, @empPassword, @empStatus, @user_create, @date_create, @user_update, @date_update, @empOrgAdtGroup)";
                SqlCommand sql_insert_user = new SqlCommand(string_insert_user, conn);

                user_create = "hanselgunawan";
                user_update = "hanselgunawan";
                date_create = DateTime.Today.ToString("yyyy-MM-dd");//harus M GEDE!
                date_update = DateTime.Today.ToString("yyyy-MM-dd");

                if (TextBoxConfirmation.Text != TextBoxPassword.Text)//jika Confirmation Password BUKAN SAMA DENGAN Password
                {
                    SpanAddUser.Attributes.Remove("disabled");
                    check_password_confirmation.Attributes.Add("style", "width:400px; visibility:visible; color:red; font-weight:bold; margin-bottom:-25px !important; margin-top:5px !important");
                    TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                    TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                    TextBoxColorConfirmation.Attributes.Add("class", "form-group has-error");
                }
                else
                {
                    check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-40px !important; margin-top:5px !important");
                    TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                    TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                    TextBoxColorConfirmation.Attributes.Add("class", "form-group has-success");

                    sql_insert_user.Parameters.AddWithValue("@empNIK", TextBoxNIK.Text);
                    sql_insert_user.Parameters.AddWithValue("@empName", TextBoxName.Value);
                    sql_insert_user.Parameters.AddWithValue("@empOrg", TextBoxOrganization.Value);
                    sql_insert_user.Parameters.AddWithValue("@empJobTitle", TextBoxJobTitle.Value);
                    sql_insert_user.Parameters.AddWithValue("@empScorecardGroup", TextBoxGroup.Value);
                    sql_insert_user.Parameters.AddWithValue("@empStatus", DropDownListStatus.SelectedValue);
                    sql_insert_user.Parameters.AddWithValue("@user_create", user_create);
                    sql_insert_user.Parameters.AddWithValue("@date_create", date_create);
                    sql_insert_user.Parameters.AddWithValue("@user_update", user_update);
                    sql_insert_user.Parameters.AddWithValue("@date_update", date_update);
                    sql_insert_user.Parameters.AddWithValue("@empOrgAdtGroup", TextBoxAdditional.Value);

                    //ubah Password dengan MD5
                    using (MD5 md5Hash = MD5.Create())
                    {
                        string hash = GetMd5Hash(md5Hash, user_password);
                        MD5_Password = hash;
                        sql_insert_user.Parameters.AddWithValue("@empPassword", MD5_Password);
                    }

                    sql_insert_user.ExecuteNonQuery();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "redirect", "alert('New Scorecard User Added'); window.location='" + Request.ApplicationPath + "scorecard_user.aspx?page=" + page + "';", true);
                }
                conn.Close();
            }
        }

        static string GetMd5Hash(MD5 md5Hash, string input)
        {
            // Convert string menjadi byte array agar bisa di hash
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Buat StringBuilder buat tampung byte-nya
            // dan membuat string baru.
            StringBuilder sBuilder = new StringBuilder();

            // Loop setiap byte array
            // dan format semua ke nilai hexadecimal
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Mengembalikan nilai Hexadecimal
            return sBuilder.ToString();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Configuration;
using System.Security.Cryptography;

namespace Balanced_Scorecard
{
    public partial class edit_user : System.Web.UI.Page
    {
        string str_connect = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var page = Request.QueryString["page"];
                var user_id = Request.QueryString["user_id"];

                string string_select_user = "SELECT * FROM ScorecardUser WHERE user_id="+user_id+"";

                DropDownListStatus.Items.Add("Yes");
                DropDownListStatus.Items.Add("No");

                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-25px !important; margin-top:5px !important");

                cancel_edit.Attributes.Add("href", "scorecard_user.aspx?page=" + page + "");//kirim balik page nya!
                scorecard_user_breadcrumb.Attributes.Add("href", "scorecard_user.aspx?page=" + page + "");//kirim balik page nya!

                TextBoxColor.Attributes.Add("class", "form-group");

                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-success");//default color

                using (SqlConnection conn = new SqlConnection(str_connect))
                {
                    conn.Open();
                    SqlCommand sql_select_user = new SqlCommand(string_select_user, conn);
                    using (SqlDataReader UserReader = sql_select_user.ExecuteReader())
                    {
                        while (UserReader.Read())
                        {
                            LabelUserNIK_Breadcrumb.Text = UserReader["empNIK"].ToString();
                            LabelUserName_Breadcrumb.Text = UserReader["empName"].ToString();
                            LabelUserNIK_Title.Text = UserReader["empNIK"].ToString();
                            LabelUserName_Title.Text = UserReader["empName"].ToString();

                            TextBoxNIK.Text = UserReader["empNIK"].ToString();
                            TextBoxName.Value = UserReader["empName"].ToString();
                            TextBoxOrganization.Value = UserReader["empOrg"].ToString();
                            TextBoxJobTitle.Value = UserReader["empJobTitle"].ToString();
                            TextBoxGroup.Value = UserReader["empScorecardGroup"].ToString();
                            TextBoxAdditional.Value = UserReader["empOrgAdtGroup"].ToString();
                            TextBoxPassword.Attributes.Add("value", UserReader["empPassword"].ToString());
                            TextBoxConfirmation.Attributes.Add("value", UserReader["empPassword"].ToString());
                            DropDownListStatus.SelectedValue = UserReader["empStatus"].ToString();
                        }
                    }
                    conn.Close();
                }
            }
        }

        protected void TextBoxConfirmation_TextChanged(object sender, EventArgs e)
        {
            if (TextBoxConfirmation.Text != TextBoxPassword.Text)//jika Confirmation Password BUKAN SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Add("disabled", "true");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:visible; color:red; font-weight:bold; margin-bottom:-5px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-error");
            }
            else//jika Confirmation Password SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Remove("disabled");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-25px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-success");
            }
        }


        protected void OnClickEditUser(object sender, EventArgs e)
        {
            var page = Request.QueryString["page"];
            var user_id = Request.QueryString["user_id"];

            if (TextBoxConfirmation.Text != TextBoxPassword.Text)//jika Confirmation Password BUKAN SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Add("disabled", "true");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:visible; color:red; font-weight:bold; margin-bottom:-5px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-error");
            }
            else//jika Confirmation Password SAMA DENGAN Password
            {
                SpanAddUser.Attributes.Remove("disabled");
                check_password_confirmation.Attributes.Add("style", "width:400px; visibility:hidden; color:red; font-weight:bold; margin-bottom:-25px !important; margin-top:5px !important");
                TextBoxPassword.Attributes.Add("value", TextBoxPassword.Text);
                TextBoxConfirmation.Attributes.Add("value", TextBoxConfirmation.Text);
                TextBoxColorConfirmation.Attributes.Add("class", "form-group has-success");

                using (SqlConnection conn = new SqlConnection(str_connect))
                {
                    conn.Open();
                    string password_in_db, user_create, date_create, user_update, date_update, MD5_Password;
                    string string_update_user = "UPDATE ScorecardUser SET empNIK=@empNIK, empName=@empName, empOrg=@empOrg, empJobTitle=@empJobTitle, empScorecardGroup=@empScorecardGroup, empPassword=@empPassword, empStatus=@empStatus, user_create=@user_create, date_create=@date_create, user_update=@user_update, date_update=@date_update, empOrgAdtGroup=@empOrgAdtGroup WHERE user_id="+user_id+"";
                    SqlCommand sql_update_user = new SqlCommand(string_update_user, conn);

                    string string_check_password = "SELECT empPassword FROM ScorecardUser WHERE user_id="+user_id+"";
                    SqlCommand sql_check_password = new SqlCommand(string_check_password, conn);
                    password_in_db = sql_check_password.ExecuteScalar().ToString();

                    user_create = "hanselgunawan";
                    user_update = "hanselgunawan";
                    date_create = DateTime.Today.ToString("yyyy-MM-dd");//harus M GEDE!
                    date_update = DateTime.Today.ToString("yyyy-MM-dd");

                    sql_update_user.Parameters.AddWithValue("@empNIK", TextBoxNIK.Text);
                    sql_update_user.Parameters.AddWithValue("@empName", TextBoxName.Value);
                    sql_update_user.Parameters.AddWithValue("@empOrg", TextBoxOrganization.Value);
                    sql_update_user.Parameters.AddWithValue("@empJobTitle", TextBoxJobTitle.Value);
                    sql_update_user.Parameters.AddWithValue("@empScorecardGroup", TextBoxGroup.Value);
                    sql_update_user.Parameters.AddWithValue("@empStatus", DropDownListStatus.SelectedValue);
                    sql_update_user.Parameters.AddWithValue("@user_create", user_create);
                    sql_update_user.Parameters.AddWithValue("@date_create", date_create);
                    sql_update_user.Parameters.AddWithValue("@user_update", user_update);
                    sql_update_user.Parameters.AddWithValue("@date_update", date_update);
                    sql_update_user.Parameters.AddWithValue("@empOrgAdtGroup", TextBoxAdditional.Value);

                    if (TextBoxPassword.Text == password_in_db)//untuk ERROR HANDLING jika ada USER memilih EDIT USER tanpa mengubah Password sama sekali
                    {
                        sql_update_user.Parameters.AddWithValue("@empPassword", TextBoxPassword.Text);
                    }
                    else//jika PASSWORD di-UPDATE
                    {
                        //ubah Password dengan MD5
                        using (MD5 md5Hash = MD5.Create())
                        {
                            string hash = GetMd5Hash(md5Hash, TextBoxPassword.Text);
                            MD5_Password = hash;
                            sql_update_user.Parameters.AddWithValue("@empPassword", MD5_Password);
                        }
                    }
                    sql_update_user.ExecuteNonQuery();
                    conn.Close();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "redirect", "alert('" + TextBoxName.Value + " (" + TextBoxNIK.Text + ") Has Been Updated'); window.location='" + Request.ApplicationPath + "scorecard_user.aspx?page=" + page + "';", true);
                }//end of SqlConnection Update
            }
        }

        static string GetMd5Hash(MD5 md5Hash, string input)
        {
            // Convert string menjadi byte array agar bisa di hash
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Buat StringBuilder buat tampung byte-nya
            // dan membuat string baru.
            StringBuilder sBuilder = new StringBuilder();

            // Loop setiap byte array
            // dan format semua ke nilai hexadecimal
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            // Mengembalikan nilai Hexadecimal
            return sBuilder.ToString();
        }

    }
}
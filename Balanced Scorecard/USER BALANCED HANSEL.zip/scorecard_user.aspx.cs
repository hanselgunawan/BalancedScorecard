﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Balanced_Scorecard
{
    public partial class scorecard_user : System.Web.UI.Page
    {
        string str_connect = ConfigurationManager.ConnectionStrings["MyConnection"].ConnectionString;
        StringBuilder HtmlTableData = new StringBuilder();//untuk Table Data-nya
        StringBuilder Pagination = new StringBuilder();//untuk Pagination
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                var paging = Request.QueryString["page"];//untuk pagination
                var nik = Request.QueryString["nik"];
                int page = 0;
                decimal no_header = 0;//inisialisasi
                decimal data_per_page = 5, max_select_data = 0, max_page = 0;//untuk pagination
                string string_select_user = "";//inisialisasi agar dinamis
                string get_max_data = "";//inisialisasi agar dinamis

                btnAddMeasure.Attributes.Add("class", "btn btn-default");

                using (SqlConnection conn = new SqlConnection(str_connect))
                {
                    conn.Open();

                    if (paging == null)//untuk pertama kali Load Page
                    {
                        page = 1;
                        no_header = (1 * data_per_page) - (data_per_page - 1);//untuk no. header kolom 1 Table jika data yang ditampilkan per halaman = 5
                    }
                    else
                    {
                        page = int.Parse(paging.ToString());
                        no_header = (page * data_per_page) - (data_per_page - 1);//agar no header tidak menjadi 1 lagi ketika di Page 2++
                    }

                    btnAddMeasure.Attributes.Add("a href", "add_user.aspx?page=" + page + "");

                    if (nik == null)//untuk Search NIK
                    {
                        get_max_data = "SELECT COUNT(user_id) FROM ScorecardUser";
                        string_select_user = "SELECT * FROM (SELECT ROW_NUMBER() OVER(ORDER BY user_id ASC) AS rowNum, user_id, empNIK, empName, empOrg, empJobTitle, empScorecardGroup, SUBSTRING(empPassword,0,8) empPass, empStatus, empOrgAdtGroup FROM ScorecardUser)sub WHERE rowNum>=((" + page + "-1)*" + data_per_page + ")+1 AND rowNum<=" + data_per_page + "*" + page + "";//sama seperti LIMIT pada MySQL
                    }
                    else
                    {
                        get_max_data = "SELECT COUNT(user_id) FROM ScorecardUser WHERE user_id=" + nik + "";
                        string_select_user = "SELECT user_id, empNIK, empName, empOrg, empJobTitle, empScorecardGroup, SUBSTRING(empPassword,0,8) empPass, empStatus, empOrgAdtGroup FROM ScorecardUser WHERE empNIK=" + nik + "";
                        TextBoxSearch.Value = nik.ToString();
                    }

                    SqlCommand sql_get_max_data = new SqlCommand(get_max_data, conn);
                    max_select_data = (int)sql_get_max_data.ExecuteScalar();//untuk mengetahui banyaknya page pada pagination
                    max_page = Math.Ceiling(max_select_data / data_per_page);//mendapatkan nilai banyaknya jumlah page

                    SqlCommand sql_select_user = new SqlCommand(string_select_user, conn);
                    using (SqlDataReader UserReader = sql_select_user.ExecuteReader())
                    {
                        if (UserReader.HasRows)
                        {
                            HtmlTableData.Append("<tr><th class='centering-th2'>No.</th><th class='centering-th2'>NIK</th><th class='centering-th2'>Name</th><th class='centering-th2'>Organization</th><th class='centering-th2'>Job Title</th><th class='centering-th2'>Group</th><th class='centering-th2'>Additional Group</th><th class='centering-th2'>Password</th><th class='centering-th2'>Active</th><th class='centering-th2'>Edit</th></tr>");
                            while (UserReader.Read())
                            {
                                HtmlTableData.Append("<tr align='center' style='border-bottom:1px solid #ddd'>");
                                HtmlTableData.Append("<td class='td-align'>" + no_header + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empNIK"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empName"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empOrg"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empJobTitle"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empScorecardGroup"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empOrgAdtGroup"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empPass"] + "...</td>");
                                HtmlTableData.Append("<td class='td-align'>" + UserReader["empStatus"] + "</td>");
                                HtmlTableData.Append("<td class='td-align'><a class='btn btn-default' href='edit_user.aspx?page=" + page + "&user_id=" + UserReader["user_id"] + "'>Edit</a></td>");
                                HtmlTableData.Append("</tr>");
                                no_header++;
                            }
                        }
                        else
                        {
                            HtmlTableData.Append("<tr><th class='centering-th2'>No User To Display</th></tr>");
                        }
                    }
                    conn.Close();
                }
                PlaceHolderTable.Controls.Add(new Literal { Text = HtmlTableData.ToString() }); //untuk Table

                //Code untuk Pagination
                Pagination.Append("<ul id='my-pagination' class='pagination'></ul>");

                //Pagination JQuery
                Pagination.Append("<script>");
                Pagination.Append("$('#my-pagination').twbsPagination({");
                Pagination.Append("totalPages: " + max_page + ",");
                Pagination.Append("visiblePages: 7,");
                Pagination.Append("href: '?page={{number}}'");
                Pagination.Append("});");
                Pagination.Append("</script>");
                PlaceHolderPaging.Controls.Add(new Literal { Text = Pagination.ToString() });//untuk Pagination
            }
        }

        protected void OnClickSearch(object sender, EventArgs e)
        {
            Response.Redirect("scorecard_user.aspx?nik=" + TextBoxSearch.Value + "");
        }

        protected void OnClickExportPDF(object sender, EventArgs e)
        {
        }

        protected void OnClickExportExcel(object sender, EventArgs e)
        {

        }
    }
}